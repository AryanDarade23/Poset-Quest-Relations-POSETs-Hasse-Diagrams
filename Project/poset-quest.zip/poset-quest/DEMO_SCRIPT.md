# Poset Quest: Live Demonstration Script (about 8 minutes)

**Before the evaluator arrives:** run `streamlit run app.py`, open `http://localhost:8501`, keep the repo open in VS Code, zoom the browser to 110%.
Expected outputs below come from the project's own code.

## Speaking order
| Time | Presenter | Part |
|---|---|---|
| 0:00 | Shriharsh Patil | Introduction, objective, architecture (30 s) |
| 0:30 | Shriharsh Patil | Demo 1 and 2: Relation Lab |
| 2:30 | Aryan Darade | Demo 3: Closures and Warshall |
| 4:00 | Avneesh Mane | Demo 4 and 5: POSET, Hasse, lattice |
| 5:30 | Atharv Torape | Demo 6: Game, tests, repo |
| 7:30 | Piyush Hingane | UI design, error handling, wrap-up |

## Demo 1: Relation Lab, a non-POSET (tab 1)
Type **A** = `a,b,c`, **R** = `(a,a),(a,b),(b,c)`.
- Matrix shows 1s at (a,a), (a,b), (b,c).
- Reflexive: No (missing (b,b), (c,c)). Transitive: No ((a,b),(b,c) in R but (a,c) not). Antisymmetric: Yes.
- Equivalence: No. POSET: No.
- *Say:* "Each failed property gives a witness, so the tool explains why, not only yes or no."

## Demo 2: Equivalence relation (tab 1)
**A** = `1,2,3,4`, **R** = `(1,1),(2,2),(3,3),(4,4),(1,2),(2,1),(3,4),(4,3)`.
- Reflexive, symmetric, transitive all pass. **Equivalence: Yes.** POSET: No.
- *Say:* "Classes are {1,2} and {3,4}."

## Demo 3: Closures and Warshall (tab 2)
Reuse **A** = `a,b,c`, **R** = `(a,a),(a,b),(b,c)`.
- Scroll the Warshall steps: W0 = M_R; allowing `b` as intermediate adds (a,c).
- Transitive closure = (a,a), (a,b), (a,c), (b,c).
- Reflexive closure adds (b,b), (c,c). Symmetric closure adds (b,a), (c,b).
- *Say:* "W[k] = W[k-1] OR (W[k-1][i][k] AND W[k-1][k][j]), complexity O(n^3)."

## Demo 4: POSET, Hasse and lattice (tab 3)
**A** = `1,2,3,4,6,12`, tick **Auto-fill divisibility**.
- Hasse edges: 1-2, 1-3, 2-4, 2-6, 3-6, 4-12, 6-12. The edge 1-4 is not drawn (transitive).
- Minimal/least = 1, maximal/greatest = 12. **Lattice: Yes**, lub(4,6) = 12, glb(4,6) = 2.
Now change **A** to `1,2,3,4,6`:
- Hasse loses 4-12 and 6-12. **Lattice: No**, pair (3,4) has no upper bound in the set.
- *Say:* "Same relation, different set, different conclusion. This shows dynamic input."

## Demo 5: Error handling (tab 1)
Untick auto-fill, **A** = `a,b`, **R** = `(a,z)`. The app shows *"Pair (a,z) uses an element not in A"* and does not crash.

## Demo 6: Game (tab 4)
- Read the shown set. Select the covering pairs. Example: for A = {1,2,3,4} the answer is 1→2, 1→3, 2→4.
- First submit a wrong answer (add 1→4): app shows Missing/Extra and reminds that transitive edges are not drawn (score -2).
- Fix it and submit: score +10 x level, level rises, set grows (3 + level elements).
- Show Hint (-3), Reveal solution (draws the Hasse diagram), Restart.
- *Say:* "Scoring and level progression are driven by the Hasse-cover definition."

## Show the code (1 minute)
Open `relations.py`: point to `hasse_edges`, `warshall`, `lattice_check`. Run `pytest tests/` (6 passed). Show README and repo structure.

## Likely viva questions (each member should answer for their own module)
- **Why not draw 1-4?** It is implied by 1-2 and 2-4; a Hasse edge needs no element strictly between.
- **Minimal vs least?** Minimal: nothing below it. Least: below every element. A poset can have several minimal elements but at most one least.
- **Is divisibility on {1,2,3} a lattice?** No, 2 and 3 have no upper bound in the set.
- **Antisymmetric vs not symmetric?** Different: an empty relation is both symmetric and antisymmetric.
- **Warshall complexity and idea?** O(n^3); allow vertices one at a time as intermediates.
- **Equivalence vs partial order?** Symmetric vs antisymmetric.
- **How is difficulty scaled?** Number of elements = 3 + level.
- **Who wrote what?** See the contribution table in the report.

## Backup plan
If the app does not start: `python -m streamlit run app.py`. If the browser fails: show the report PDF figures and run `python -c "import relations as r; ..."`. Keep this script open on a phone.
