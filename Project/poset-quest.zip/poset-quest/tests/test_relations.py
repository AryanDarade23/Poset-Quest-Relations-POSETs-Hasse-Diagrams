import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import relations as rl

A = ["1", "2", "3", "6"]
DIV = {(a, b) for a in A for b in A if int(b) % int(a) == 0}


def test_div_is_poset():
    assert rl.is_poset(A, DIV)


def test_hasse_edges():
    assert set(rl.hasse_edges(A, DIV)) == {("1", "2"), ("1", "3"), ("2", "6"), ("3", "6")}


def test_lattice():
    assert rl.lattice_check(A, DIV)[0]
    assert rl.lub(A, DIV, "2", "3") == "6" and rl.glb(A, DIV, "2", "3") == "1"


def test_not_lattice():
    B = ["1", "2", "3"]
    R = {(a, b) for a in B for b in B if int(b) % int(a) == 0}
    assert not rl.lattice_check(B, R)[0]   # 2,3 have no lub


def test_warshall_closure():
    B = ["a", "b", "c"]
    assert rl.transitive_closure(B, {("a", "b"), ("b", "c")}) == {("a", "b"), ("b", "c"), ("a", "c")}


def test_properties():
    p = rl.properties(["a", "b"], {("a", "b")})
    assert not p["Reflexive"][0] and p["Antisymmetric"][0] and not p["Symmetric"][0]
